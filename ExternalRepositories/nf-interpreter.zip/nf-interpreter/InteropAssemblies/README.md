
This folder contains the configuration file for the Assemblies Table collection.

It's a placeholder for the Interop assemblies source files.
The source files for each Interop assembly should be placed in it's own folder.
Anything inside this folder is ignored by an exception pattern in .gitignore file.
