//
// Copyright (c) .NET Foundation and Contributors
// Portions Copyright (c) Microsoft Corporation.  All rights reserved.
// See LICENSE file in the project root for full license information.
//

#ifndef _TARGET_PAL_BLOCKSTORAGE_H_
#define _TARGET_PAL_BLOCKSTORAGE_H_ 1

#include <nanoPAL_BlockStorage.h>

#endif  // _TARGET_PAL_BLOCKSTORAGE_H_
