//
// Copyright (c) .NET Foundation and Contributors
// See LICENSE file in the project root for full license information.
//

#ifndef _TARGET_PAL_TIME_H_
#define _TARGET_PAL_TIME_H_ 1


#endif //_TARGET_PAL_TIME_H_
