//
// Copyright (c) .NET Foundation and Contributors
// Portions Copyright (c) Microsoft Corporation.  All rights reserved.
// See LICENSE file in the project root for full license information.
//

////////////////////////////////////////////////////////////////////////////
// This is header file is empty on purpose.                               //
// It has to exist here in order to keep Visual Studio C++ compiler happy //
// to use pre-processed headers for WIN32 projects                        //
////////////////////////////////////////////////////////////////////////////
